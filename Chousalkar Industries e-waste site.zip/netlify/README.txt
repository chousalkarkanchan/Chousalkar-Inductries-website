Publish on Netlify
1. app.netlify.com > Add new site > Deploy manually.
2. Drag this whole folder onto the upload area.
3. Pages live at: / (Home), /about, /services, /process, /business, /contact, /privacy, /terms
   index.html contains every page; _redirects makes each address open the right one, and the browser Back button works.
4. Custom domain: Site configuration > Domain management > Add a domain > chousalkarindustries.com.
